import React from "react";

const MainLayouts = ({ children }) => {
  return <React.Fragment>{children}</React.Fragment>;
};

export default MainLayouts;
